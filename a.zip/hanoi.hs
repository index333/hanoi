import System.Directory 
import System.FilePath.Posix

doHanoi o d t [_] = putStrLn $ o:d:[]
doHanoi o d t ds = do
    doHanoi o t d $ init ds
    doHanoi o d t $ [last ds]
    doHanoi t d o $ init ds
main = do
    fs <- listDirectory "." 
    let bs = filter (isExtensionOf "gif") fs
    let n = length bs
    let a = 'A'
    let b = 'B'
    let c = 'C'
    doHanoi a b c [1..n]
