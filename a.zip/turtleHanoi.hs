import  Control.Monad.State 
import Control.Monad
import System.Directory 
import System.FilePath.Posix
import System.Environment
getI :: IO Int
getI = getArgs >>= \(a:_) -> (return . read) a
ds n = ["t" ++ show x | x <- [1..n]]
getc = getContents >>= (return . lines)
tMove t (x, y)= liftIO $ tGoto t (x,y*10)
move "AB" = get >>= \(a:aa,b,c) -> put (aa,a:b,c) >> tMove a (0, length b)
move "AC" = get >>= \(a:aa,b,c) -> put (aa,b,a:c) >> tMove a (200, length c)
move "BA" = get >>= \(a,b:bb,c) -> put (b:a,bb,c) >> tMove b (-200, length a)
move "BC" = get >>= \(a,b:bb,c) -> put (a,bb,b:c) >> tMove b (200, length c)
move "CA" = get >>= \(a,b,c:cc) -> put (c:a,b,cc) >> tMove c (-200, length a)
move "CB" = get >>= \(a,b,c:cc) -> put (a,c:b,cc) >> tMove c (0,length b)
move _ = return ()
doHanoi [] = return () 
doHanoi (x:xs) = do 
    move x
    (a,b,c) <- get
    doHanoi xs
main = do
    fs <- listDirectory "."
    let bs = filter (isExtensionOf "gif") fs
    let n = length bs
    start
    mkScreen
    let gifs = [show x ++ ".gif" | x <- [1..n]]
    mapM_ registerGif gifs
    let tns = ["t" ++ show x|x <- [1..n]]
    ts <- mapM mkTurtle tns
    mapM_ tPenUp tns
    s <- getI
    mapM_ (\x -> tSpeed x s) tns
    zipWithM tShape tns gifs
    zipWithM (\t y -> tGoto t (-200 ,y)) (reverse tns) [0 ,10..(n-1)*10]
    let a = ds n
    let b = []
    let c = []
    code <- getc
    runStateT (doHanoi code) (a,b,c) >> end

start = putStrLn "import turtle"
mkScreen = putStrLn "screen=turtle.Screen()"
registerGif :: FilePath -> IO ()
registerGif x = putStrLn $ "screen.register_shape(" ++ show x ++ ")"
mkTurtle x = putStrLn $ x ++ "=turtle.Turtle()"
tShape t x = putStrLn $ t ++ ".shape(" ++ show x ++ ")"
tGoto t p = putStrLn $ t ++ ".goto" ++ show p 
tPenUp t = putStrLn $ t ++ ".penup()"
tSpeed t x = putStrLn $ t ++ ".speed(" ++ show x ++ ")"
end = putStrLn "screen.mainloop()"
