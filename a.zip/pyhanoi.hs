import Control.Monad
start = putStrLn "import turtle"
mkScreen = putStrLn "screen=turtle.Screen()"
registerGif :: FilePath -> IO ()
registerGif x = putStrLn $ "screen.register_shape(" ++ show x ++ ")"
mkTurtle x = putStrLn $ x ++ "=turtle.Turtle()"
tShape t x = putStrLn $ t ++ ".shape(" ++ show x ++ ")"
tGoto t p = putStrLn $ t ++ ".goto" ++ show p 
tPenUp t = putStrLn $ t ++ ".penup()"
end = putStrLn "screen.mainloop()"
main = do
    start
    mkScreen
    let gifs = [show x ++ ".gif" | x <- [1..9]]
    mapM_ registerGif gifs
    let tns = ["t" ++ show x|x <- [1..9]]
    ts <- mapM mkTurtle tns
    mapM_ tPenUp tns
    zipWithM tShape tns gifs
    zipWithM (\t y -> tGoto t (-200 ,y)) (reverse tns) [0 ,10..80]
    end
    
