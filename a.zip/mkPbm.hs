import System.Process
import System.Environment
import System.Directory 
import System.FilePath.Posix
import System.Posix.Files

getI :: IO Int
getI = getArgs >>= \(a:_) -> (return . read) a
pbm w = ["P1" ,(show w), "10" , line w]
line w = take (10 * w) $ repeat '1'
toGif x = createProcess(proc "convert" [show x ++ ".pbm",show x ++ ".gif"])     >> return ()
main = do
    fs <- listDirectory "." 
    let fss = filter (isExtensionOf "pbm") fs
    mapM_ removeLink fss
    let fsss = filter (isExtensionOf "gif") fs
    mapM_ removeLink fsss
    n <- getI
    mapM_ (\x -> writeFile ((show x) ++ ".pbm") (unlines (pbm (x * 10))))  
        [1..n]
    mapM_ toGif [1..n]
