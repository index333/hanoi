pbm w f = do
    putStrLn "P1"
    putStrLn $ show w 
    putStrLn "10"
    mapM_ (\_ -> line w) [1..10]
     
line w = do
    mapM_ (\_ -> putStr "1 ") [1 .. w]
    putStrLn ""
    
main = pbm 10 ""
